const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const dotenv = require('dotenv');

dotenv.config();

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL:
        `${process.env.NODE_ENV === 'production'
          ? 'https://navarrojalen-api.up.railway.app'
          : 'http://localhost:4000'}/api/auth/google/callback`,
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        // 🔍 Log full Google profile (safe to remove in production)
        console.log('🔍 Google Profile:', JSON.stringify(profile, null, 2));

        // 👤 Return profile (your app handles user creation/token logic later)
        return done(null, profile);
      } catch (err) {
        console.error('❌ GoogleStrategy error:', err);
        return done(err, null);
      }
    }
  )
);

// ✅ These are required even without sessions due to Passport internals
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((user, done) => done(null, user));
