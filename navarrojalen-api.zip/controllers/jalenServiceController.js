const JalenService = require('../models/jalenServiceModel');
const User = require('../models/userModel');
const Order = require('../models/orderModel');
const jwt = require('jsonwebtoken');

// GET all services
exports.getAllServices = async (req, res) => {
  try {
    const services = await JalenService.find().sort({ createdAt: -1 });
    res.json(services);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch services' });
  }
};

// GET service by ID
exports.getServiceById = async (req, res) => {
  try {
    const service = await JalenService.findById(req.params.id);
    if (!service) return res.status(404).json({ error: 'Not found' });
    res.json(service);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching service' });
  }
};

// CREATE new service
exports.createService = async (req, res) => {
  try {
    const service = new JalenService(req.body);
    await service.save();
    res.status(201).json(service);
  } catch (err) {
    res.status(400).json({ error: 'Error creating service', details: err.message });
  }
};

// UPDATE service
exports.updateService = async (req, res) => {
  try {
    const service = await JalenService.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!service) return res.status(404).json({ error: 'Service not found' });
    res.json(service);
  } catch (err) {
    res.status(400).json({ error: 'Error updating service', details: err.message });
  }
};

// DELETE service
exports.deleteService = async (req, res) => {
  try {
    const result = await JalenService.findByIdAndDelete(req.params.id);
    if (!result) return res.status(404).json({ error: 'Not found' });
    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Delete failed' });
  }
};

// 🪙 Give credits
exports.giveCreditsToUser = async (req, res) => {
  const { email, amount } = req.body;

  if (!email || amount === undefined) {
    return res.status(400).json({ error: 'Missing email or amount' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ error: 'User not found' });

    user.njCredits = (user.njCredits || 0) + amount;
    await user.save();

    res.json({ message: 'Credits added', balance: user.njCredits });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add credits', details: err.message });
  }
};

// 🧾 Use credits to order
exports.useCreditsForOrder = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  const { serviceId, tierName, amount } = req.body;

  if (!token || !serviceId || !tierName || !amount) {
    return res.status(400).json({ error: 'Missing fields or token' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if ((user.njCredits || 0) < amount) {
      return res.status(400).json({ error: 'Insufficient credits' });
    }

    user.njCredits -= amount;
    await user.save();

    await Order.create({
      userId: user._id,
      serviceId,
      tierName,
      amount,
      isPaid: true,
      paymentId: `NJCREDIT-${Date.now()}`,
    });

    res.json({ message: 'Paid with NJCredits', balance: user.njCredits });
  } catch (err) {
    res.status(500).json({ error: 'Credit payment failed', details: err.message });
  }
};

// 🧑 Get user info
exports.getUserInfo = async (req, res) => {
  const authHeader = req.headers.authorization;

  // Check if the Authorization header is missing or malformed
  if (!authHeader?.startsWith('Bearer ')) {
    console.error('Authorization header is missing or malformed.');
    return res.status(401).json({ error: 'Authorization header missing or malformed' });
  }

  const token = authHeader.split(' ')[1]; // Extract token from 'Bearer <token>'

  try {
    // Decode the JWT token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log('[Decoded Token]', decoded); // Log the decoded token to verify its content

    // Fetch user from the database using the decoded ID (This is where we directly access the DB)
    const user = await User.findById(decoded.id).select('email name picture njCredits');

    if (!user) {
      console.warn('[User not found]', decoded.id);
      return res.status(404).json({ error: 'User not found' });
    }

    // Return the user information from the database
    return res.status(200).json({
      _id: user._id,
      email: user.email,
      name: user.name,
      picture: user.picture,
      njCredits: user.njCredits,
    });
  } catch (err) {
    console.error('[JWT Decode Error]', err.message);

    // Handle specific JWT errors (expired, invalid)
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    if (err.name === 'JsonWebTokenError') {
      return res.status(403).json({ error: 'Invalid token' });
    }

    // General error if JWT decode fails or something unexpected happens
    return res.status(500).json({ error: 'Failed to get user info', details: err.message });
  }
};






// 🔁 Admin fetch all users
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('name email njCredits');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users', details: err.message });
  }
};

// 🛠️ Admin sets credits manually
exports.setUserCredits = async (req, res) => {
  const { credits } = req.body;

  if (credits === undefined) {
    return res.status(400).json({ error: 'Credits value required' });
  }

  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { njCredits: credits },
      { new: true }
    );
    if (!user) return res.status(404).json({ error: 'User not found' });

    res.json({ message: 'Credits updated', user });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update credits', details: err.message });
  }
};
