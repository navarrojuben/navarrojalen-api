const mongoose = require('mongoose');

const tierSchema = new mongoose.Schema({
  name: {
    type: String,
    enum: ['Basic', 'Standard', 'Premium'],
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  price: {
    type: Number,
    required: true
  },
  deliveryTime: {
    type: Number, // in days
    required: true
  },
  revisions: {
    type: String,
    required: true
  },
  features: {
    type: [String],
    default: []
  }
}, { _id: false });

const jalenServiceSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: String,
  tiers: {
    type: [tierSchema],
    validate: [tiers => tiers.length === 3, 'Exactly 3 tiers required']
  }
}, { timestamps: true });

module.exports = mongoose.model('JalenService', jalenServiceSchema);
