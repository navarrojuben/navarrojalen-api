const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true, // ✅ good practice to avoid duplicate Google accounts
  },
  password: {
    type: String,
    default: '', // ✅ Required for Google-auth-only users
  },
  picture: {
    type: String,
    default: '', // ✅ helps avoid undefined on frontend
  },
  njCredits: {
    type: Number,
    default: 50,
  },
}, { timestamps: true }); // ✅ optional: adds createdAt/updatedAt

module.exports = mongoose.model('User', userSchema);
