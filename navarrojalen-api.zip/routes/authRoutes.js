const router = require('express').Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

const FRONTEND_URL =
  process.env.NODE_ENV === 'production'
    ? 'https://navarrojalen.netlify.app'
    : 'http://localhost:3000';

// 🔐 Start Google OAuth
router.get(
  '/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

// 🔐 Callback after Google login
router.get(
  '/google/callback',
  passport.authenticate('google', {
    session: false,
    failureRedirect: `${FRONTEND_URL}/store/login`,
  }),
  async (req, res) => {
    try {
      const profile = req.user;

      if (!profile) {
        console.error('❌ Google profile not received.');
        return res.redirect(`${FRONTEND_URL}/store/login?error=no_profile`);
      }

      // ✅ Extract email and name safely
      const email = profile?.emails?.[0]?.value || profile?._json?.email;
      const name = profile?.displayName || profile?._json?.name || 'Unnamed';
      const picture = profile?.photos?.[0]?.value || profile?._json?.picture || '';

      if (!email) {
        console.error('❌ Missing email in profile:', profile);
        return res.redirect(`${FRONTEND_URL}/store/login?error=missing_email`);
      }

      // ✅ Find or create user
      let user = await User.findOne({ email });
      if (!user) {
        user = await User.create({
          name,
          email,
          password: '', // no password for OAuth users
          njCredits: 50,
          picture,
        });
        console.log(`🟢 New user created: ${email}`);
      } else {
        console.log(`🟢 Existing user logged in: ${email}`);
      }

      // ✅ Issue JWT token
      const token = jwt.sign(
        {
          id: user._id,
          email: user.email,
          name: user.name,
          picture: user.picture,
        },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
      );

      console.log('✅ Token generated and redirecting...');
      return res.redirect(`${FRONTEND_URL}/oauth/callback?token=${token}`);
    } catch (err) {
      console.error('❌ Error in Google OAuth callback:', err);
      return res.redirect(`${FRONTEND_URL}/store/login?error=oauth_failed`);
    }
  }
);

module.exports = router;
