const express = require('express');
const router = express.Router();
const controller = require('../controllers/jalenServiceController');

// --- Service CRUD ---
router.get('/', controller.getAllServices);
router.get('/:id', controller.getServiceById);
router.post('/', controller.createService);
router.put('/:id', controller.updateService);
router.delete('/:id', controller.deleteService);

// --- NJ Credits ---
router.post('/add-credits', controller.giveCreditsToUser);
router.post('/use-credits', controller.useCreditsForOrder);
router.get('/userinfo', controller.getUserInfo);

// --- NJ Credits Admin Users ---
router.get('/users', controller.getAllUsers);               // ✅ Admin: View all users
router.put('/users/:id/credits', controller.setUserCredits); // ✅ Admin: Set credits for user by ID

module.exports = router;
