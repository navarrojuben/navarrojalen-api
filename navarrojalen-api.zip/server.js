const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const session = require('express-session');
const passport = require('passport');
require('./config/passportSetup'); // ✅ Google OAuth setup

dotenv.config();

const app = express();

// ✅ Update this to your actual frontend production domain
const allowedOrigins = [
  'http://localhost:3000',
  'https://navarrojalen.netlify.app', // ✅ PRODUCTION FRONTEND
];

app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps or curl)
    if (!origin || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
}));

// ✅ Session middleware
app.use(session({
  secret: process.env.SESSION_SECRET || 'keyboard cat',
  resave: false,
  saveUninitialized: false,
}));

// ✅ Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// ✅ JSON body parser
app.use(express.json());

// ✅ Root Route
app.get('/', (req, res) => {
  res.send('<h2>✅ Backend is working and CORS is allowed.</h2>');
});

// ✅ Auth (Google login)
app.use('/api/auth', require('./routes/authRoutes'));

// ✅ Store / Jalen services
app.use('/api/jalenservices', require('./routes/jalenServiceRoutes'));

// ✅ Other project routes
app.use('/api/projects', require('./routes/projectRoutes'));
app.use('/api/links', require('./routes/linkRoutes'));
app.use('/api/codes', require('./routes/codeRoutes'));
app.use('/api/messages', require('./routes/messageRoutes'));
app.use('/api/dates', require('./routes/dateRoutes'));
app.use('/api/notes', require('./routes/noteRoutes'));
app.use('/api/images', require('./routes/imageRoute'));
app.use('/api/presentations', require('./routes/presentationRoutes'));
app.use('/api/image-categories', require('./routes/imageCategoryRoutes'));
app.use('/api/resume', require('./routes/resumeRoutes'));

// ✅ MongoDB connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('🟢 MongoDB connected'))
.catch(err => console.error('🔴 MongoDB connection error:', err));

// ✅ Start server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
